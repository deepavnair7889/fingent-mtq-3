<?php
	
	require_once('config/dbConnect.php');
    $con = dbConnect ();

	if (isset ($_GET['code']) && !empty ($_GET['code'])) {
		$code = trim($_GET['code']);
		$stmt = $con->prepare("SELECT long_url FROM short_urls WHERE short_code =?");		
        $stmt->bind_param("s", $code);
        $stmt->execute();
        $result = $stmt->get_result();
        $data = $result->fetch_assoc();

    	if ( !empty ($data) ) {
			header("Location: " . $data['long_url']);			
			die();
		} else
            $message = '<font color="red">Sorry, unable to redirect to this url</font>';
	}