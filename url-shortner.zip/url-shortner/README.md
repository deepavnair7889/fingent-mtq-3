1. Create a database named - url_shortner
   I have given db user name as root and no password.
   If your db connection config are different, change  it in config/allconfig.php
2. Import url_shortner.sql file attached.
3. Create a virtual host entry as below
   <VirtualHost *:80>    
    DocumentRoot "D:/softwares/xamp8.0/htdocs/url-shortner"
    ServerName shortcodebuilder.com
</VirtualHost>
4. Add shortcodebuilder.com in windows host file.
5. Restart xamp;
6. .htacces file should be enabled in local server.
7. Place the files in your htdocs folder.
8. Call http://localhost/url-shortner/   in browser 
9.It is created in windows 11, Xamp, php 8 version