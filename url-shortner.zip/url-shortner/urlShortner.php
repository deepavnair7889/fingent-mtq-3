<?php
    
    require_once('config/dbConnect.php');
    $con = dbConnect();

    $message = $result = $shortenedUrl = '';    
    if (isset ($_POST['url']) && !empty ($_POST['url']) )
        $url = trim ($_POST['url']);
    else {
        $url = '';
        $message =  'No url found';
    }
    //check  url is valid
    if ( checkUrl ($url) == true ) {       
        $code = createShortcode();                
        $stmt = $con->prepare("INSERT INTO short_urls (long_url,short_code,created_on) VALUES (?,?,?)"); 
        $now = date('Y-m-d H:i:s');       
        $stmt->bind_param("sss", $url, $code, $now);
        $stmt->execute();
        $id = $stmt->insert_id;
            if ($id) {                            
                $shortenedUrl  = URL_DOMAIN_NAME . $code;
                $message = 'URL Shortened Successfully';
            } else
                $message = 'Unable to shorten given url';
    } else
        $message = 'Please enter a valid url';

    echo json_encode (['message' => $message, 'short_url' => $shortenedUrl]);
    die();

    
    function checkUrl($url) {        
        // check whether user trying to shortnen our domain and check valid url
        if (substr ($url, 0, strlen (URL_DOMAIN_NAME)) != URL_DOMAIN_NAME) {
            return filter_var ($url, FILTER_VALIDATE_URL);
        } else
            return false;
    }

    function createShortCode () {       
        $shortCode = randomCodeCreator();        
        // check code alreafy taken
        while (checkCodeExists ($shortCode) > 0)
            $shortCode = randomCodeCreator ();
                
        return $shortCode;
    }

    function randomCodeCreator (){
        $charset  = str_shuffle (CHARSET);
        return substr ($charset, 0, URL_LENGTH);        
    }

    
    function checkCodeExists ($code) {
        global $con;
	    // check code exists
	    $result      = $con->query("SELECT COUNT(*) AS count FROM short_urls WHERE short_code = '$code' ") ;        
        $resultCount = $result->fetch_all(MYSQLI_ASSOC);        
            if (!empty ($resultCount )) 
                return $resultCount[0]['count'];
            else  return 0;
    }