<?php

// db connection
define("HOST", 'localhost');
define("DB_USERNAME", 'root');
define("DB_PASSWORD", '');
define("DB_NAME", 'url_shortner');

define("URL_LENGTH", 7);
define("URL_DOMAIN_NAME", 'http://shortcodebuilder.com/');

// character set for the url shortcodes
define("CHARSET", "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ");

