<?php
    require_once('config/allConfig.php');

    function dbConnect() {
        $con = new mysqli(HOST, DB_USERNAME, DB_PASSWORD, DB_NAME);
        if ($con->connect_error) 
            die("Connection failed: " . $con->connect_error);
          
        return $con;
    }