<?php 
    include('redirect.php'); 
?>
<html lang="en-US">
<head>
<title>URL Shortener</title>
<style>
    #url{
        width: 345px !important;
    }
    .content{
        margin: 12% 25%;
        border: 1px solid #c0c0c0;
        border-radius : 5px;
    }
    
</style>
<meta charset="utf-8">
</head>
    <body>
        <div align="center" class="content">
            <div>
                <h2> URL Shortener</h2>
            </div>
            <div>
                <label>Enter a url </label>			
                <table >
                    <form method="post" action="#" id="shortnerform">
                        <tr>
                            <td>
                                <input type="text" name="url" id="url"  placeholder="http://" style="width: 100%;" /></td>
                            <td>
                                <input type="submit" value="Generate Short URL" /></td>
                        </tr>
                    </form>
                </table>
                
                <h5 id="message"><?php echo ( isset($message) ? $message : '' );?></h5>
                <span id="link"></span>            
            </div>
        </div>	
    </body>
</html>



<script type="text/javascript" src="./assets/js/jquery-3.6.1.min.js"></script>
<script>	
	$(document).ready(function() {		
		$("#shortnerform").submit(function(e) {		
            $("#message").css("color","");	
			var url = $("#url").val();			
			if ($.trim (url) != '') {				
				$.post ("urlShortner.php", {url:url}, function(data){
                    var response = JSON.parse(data);					
						$("#url").val(response.short_url).focus();
						$("#message").html(response.message);
                        $("#link").html("<a href='"+response.short_url+"' target='_blank'>"+response.short_url+"</a>");
                        if (response.short_url == '') {
                            $("#message").css("color","red");
                        } else {
                            $("#message").css("color","green");
                        }					
				});	
			} else { 
                alert("Enter URL"); 
                return false;
            }			
			return false;
		});
	});
</script>